from django.contrib import admin
from easy_lsml.models import EasyProjectLog

# Register your models here.
admin.site.register(EasyProjectLog)
